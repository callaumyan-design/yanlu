const CACHE = "yanlu-v4";
const ASSETS = [
  "./assets/index-Dnj29aY-.js",
  "./assets/index-mKoyQXkg.css",
  "./assets/ort-wasm-simd-threaded-qh98TCA_.wasm",
  "./favicon.svg",
  "./icons/apple-touch-icon.png",
  "./icons/icon-1024.png",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./index.html",
  "./manifest.webmanifest",
  "./models/SHA256SUMS",
  "./models/ch_PP-LCNet_x0_25_textline_ori_cls_mobile.onnx",
  "./models/ch_PP-OCRv5_det_mobile.onnx",
  "./models/ch_PP-OCRv5_rec_mobile.onnx",
  "./models/ppocrv5_dict.txt"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then(async (cache) => {
      for (const asset of ASSETS) {
        const response = await fetch(asset);
        if (!response.ok) throw new Error("cache " + asset);
        await cache.put(asset, response);
      }
    }).then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))),
    ).then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) {
    event.respondWith(Promise.reject(new Error("blocked")));
    return;
  }
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((response) => {
        const copy = response.clone();
        caches.open(CACHE).then((cache) => cache.put(event.request, copy)).catch(() => {});
        return response;
      });
    }),
  );
});
